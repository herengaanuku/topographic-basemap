#Name: Update_OfflineAreas.py
#Tags: PocketMaps, Topo Basemap, Offline, Update
#Last updated 17 May 2024
#Author - Julian Hitchman - Senior GIS Analyst, Herenga ā Nuku Aotearoa | Outdoor Acces Commission.
#Version: 1.1
#Deployment Location: Local or Python Notebook
#Target Environemnt: ArcGIS Online or ArcGIS Enterprise.

#Description
#This short script should be used as part of the update pipeline for your offline areas in your webmaps enabled for offline use. 
# The script contains a list of production webmaps which it calls in a for loop after logging into AGOL or ArcGIS Enterprise.



from IPython.display import display
import arcgis
from arcgis.gis import GIS
from arcgis.mapping import WebMap
import time 
import datetime 
import timeit
import arcpy

def mainUpdateOfflineAreas():

    #Start script timer
    start= timeit.default_timer()
    arcpy.AddMessage ("Starting timer for mainUpdateOfflineAreas... Beginning script...")

    #Get credentials for login
    import keyring
    username = "YourUSername" #Add your username
    password = keyring.get_password("WindowsCredentialName", "YourUsername") #Add your Windows Credential name and username.

    gis = GIS("https://yourenviornment.arcgis.com", username, password) # Add your chosen update environment.

    regionMaps = [
    # tuple containing webmap name and itemID
        ('WebMapName1', 'ItemID1'), #Add your webmaps here
        ('WebMapName2', 'ItemID2'), #Add your webmaps here
        ('WebMapName2', 'ItemID3'), #Add your webmaps here

    ]

    #begin looping through above list and updating the webmap
    
    for regionMap in regionMaps:
        arcpy.AddMessage ('Updating ' + regionMap[0])
        wm_item = gis.content.get(regionMap[1])

        # create a WebMap object from the existing web map item
        wm = WebMap(wm_item)
        type(wm)
        wm.update()
        
        
        #list offline areas associated with webmap
        offlineAreasList = wm.offline_areas.list()
        for offlineArea in offlineAreasList:
            wm.offline_areas.update()
        arcpy.AddMessage  (str(regionMap[0]) + " offline areas updated.")
        
    arcpy.AddMessage  ('All maps and offline areas updated')
    arcpy.AddMessage  ("Script Complete")

    stop = timeit.default_timer()

    secondsElapsed = round(((stop - start)), 1)
    minutesElapsed = round((secondsElapsed/60), 1)
    hoursElapsed = round((minutesElapsed/60), 2)

    if secondsElapsed < 60:
        arcpy.AddMessage ("Time taken: " + str(secondsElapsed) + " seconds.")
    elif secondsElapsed > 60 and secondsElapsed <3600:
        arcpy.AddMessage ("Time taken: " + str(minutesElapsed) + " minutes.")
    elif minutesElapsed > 60:
        arcpy.AddMessage ("Time taken: " + str(hoursElapsed) + " hours.")

if __name__ == '__main__': 
    mainUpdateOfflineAreas()
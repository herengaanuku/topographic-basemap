############################################################
#Name: Update_Datasets.py
#Version: 1.0
#Creation Date: 17-05-2024
#Last updated: 17-05-2024
#Author - Julian Hitchman - Senior GIS Analyst, Herenga ā Nuku Aotearoa | Outdoor Acces Commission.
#Deployment Location: Local or Python Notebook
#Target Environemnt: ArcGIS Online or ArcGIS Enterprise.

#About: This script utilises ArcGIS Python API and a modified version of the WFSDownload script
# to download datasets via WFS or ArcGIS Python API to a download folder and then truncate and append them.
# Once downloaded to Update.gdb, each dataset downloaded is used to update current data to the Data.gdb.
# Once this process has completed, Update_VectorTileService.py can be run.


########################################################

import os
import arcpy
import glob
import arcgis
from urllib.parse import urljoin
import WFSDownload
from WFSDownload import mainFunction
import time
import timeit
import datetime
from arcgis.gis import GIS
from arcgis.features import FeatureLayer
import time 
import datetime 
import timeit

def mainUpdateDatasets():

    #Start script timer
    start= timeit.default_timer()
    arcpy.AddMessage ("Starting mainUpdateDatasets timer... Beginning script...")

    #Set overwrite outputs to be True
    arcpy.env.overwriteOutput = True

    #PRIMARY VARIABLES 
    #Set temp environment. 
    arcpy.env.scratchWorkspace = r"YourTempGDBPath.gdb"

    #Primary output workspace for all downloaded data
    updateWorkspace = r"\\Update.gdb"
    targetWorkspace = r"\\Data.gdb"

    #Scratch workspaces used by WFSDownload Tool
    scratchWS = arcpy.env.scratchFolder
    scratchGDB =arcpy.env.scratchGDB

    #API Key used for LINZ WFS - add your own here. 
    APIKey = ""

    #ArcGIS Online DOC and LINZ Server variables - FIXED
    DOC_url = "https://services1.arcgis.com/3JjYDyG3oajxU6HO/ArcGIS/rest/services/"
    fgdb = updateWorkspace

    #Example DOC datasets. Add use or replace with whatever data you need. 
    AGOL_datasets = (("DOCDatasetName1", DOC_url),
                    ("DOCDatasetName2", DOC_url),
                    )
    
    # WFS Dataset variables - Dataset name, LINZ Dataset ID - combined together in API call. Example datasets below. Replace with your own chosen WFS Data.
    WFS_Datasets = (("ExampleLINZWFSDataset1", "layer-51153"),
                    ("ExampleLINZWFSDataset2", "layer-50332"),

    )


    # Runs through and cleans out datasets from Download.gdb and Scratch.GDB
    def cleanUp():

        #Delete existing downloaded feature classes in Download.gdb
        arcpy.AddMessage ("Process: CLEARING Download.gdb & Scratch.gdb")
        
        #Create list of GDB to be cleared before download commences
        arcpy.env.workspace = updateWorkspace
        FeatureClasses = arcpy.ListFeatureClasses()
        EmptyList =[]
        if FeatureClasses == EmptyList:
            arcpy.AddMessage (updateWorkspace + " featureclasses already deleted...")
        else:
            for FeatureClass in FeatureClasses:
                arcpy.Delete_management(FeatureClass)
                arcpy.AddMessage ("Process: "+ FeatureClass + " has been deleted....")
        # arcpy.AddMessage (workspace + " GDB cleared...")

        #Delete existing downloaded feature classes in Scratcg,gdb
        arcpy.env.workspace = scratchGDB
        FeatureClasses = arcpy.ListFeatureClasses()
        EmptyList =[]
        if FeatureClasses == EmptyList:
            arcpy.AddMessage (scratchGDB + " featureclasses already deleted...")
        else:
            for FeatureClass in FeatureClasses:
                arcpy.Delete_management(FeatureClass)
                arcpy.AddMessage ("Process: "+ FeatureClass + " has been deleted....")
        arcpy.AddMessage (scratchGDB + " GDB cleared...")
            
    #Calls DOC datasets from ArcGIS Online and copies them locally 
    def AGOLMain():
        
        #Begin downloading new data
        gis = GIS()
        arcpy.AddMessage("Connected to ArcGIS Online")
        arcpy.AddMessage("Downloading ArcGIS Online Data........")

        for dataset in AGOL_datasets:
            #Copy DOC Data using ArcGIS Python API via ArcGIS Online
            url_fl = (str(dataset[1])) + (str(dataset[0])) + "/FeatureServer/0"
            fl = FeatureLayer(url_fl)
            fs = fl.query(where = "1=1")
            fc = str(dataset[0])
            fs.save(fgdb, fc)
            arcpy.AddMessage (str(fc) + "...Saved")

        arcpy.AddMessage("All DOC Data downloaded.....")
        arcpy.AddMessage("Beginning LINZ Data Download.....")

    #Primary function which calls the WFSDownload module (located in the same folder as this script)
    def WFSMain(wfsURL,wfsVersion,wfsDataID,dataType,extentDataset,lastUpdateFile,changesetDatasetID,targetDatasetID,wfsDownloadType,outputWorkspace,datasetName):

        try:
            WFSDownload.mainFunction(wfsURL,wfsVersion,wfsDataID,dataType,extentDataset,lastUpdateFile,changesetDatasetID,targetDatasetID,wfsDownloadType,outputWorkspace,datasetName)
        except Exception as e:
            arcpy.AddMessage(e)

    #Space below for inserting Truncate & Append workflow as a function that can be called.
    # Basic function to update single Target Dataset
    def DataUpdating(Dataset_Downloaded, Dataset_ToBeUpdated, BackUp_Dataset):  # Data Back Up and Update (Truncating Tables)

        # To allow overwriting outputs change overwriteOutput option to True.
        arcpy.env.overwriteOutput = True

        # Process: Append (4) (Append) (management)
        BackUp_Tested = arcpy.management.Append(inputs=[Dataset_Downloaded], target=BackUp_Dataset)[0]

        # Process: Truncate Table (Truncate Table) (management)
        if BackUp_Tested:
            BackUp_Truncated = arcpy.management.TruncateTable(in_table=BackUp_Dataset)[0]
        # Process: Append (Append) (management)
            BackUp_Updated = arcpy.management.Append(inputs=[Dataset_ToBeUpdated], target=BackUp_Truncated)[0]

        # Process: Truncate Table (3) (Truncate Table) (management)
        if BackUp_Tested and BackUp_Updated:
            Dataset_ToBeUpdated_Truncated = arcpy.management.TruncateTable(in_table=Dataset_ToBeUpdated)[0]

        # Process: Append (3) (Append) (management)
        if BackUp_Tested and BackUp_Updated and Dataset_ToBeUpdated_Truncated:
            Dataset_Updated = arcpy.management.Append(inputs=[Dataset_Downloaded], target=Dataset_ToBeUpdated_Truncated)[0]

    # Function to update all datasets in PRD
    def update_Data(WFS_datasets,AGOL_datasets):
        for dataset in WFS_datasets:
            fc = dataset[0]
            #update external
            target_ws = targetWorkspace
            DataUpdating(os.path.join(updateWorkspace,fc),os.path.join(target_ws,fc), os.path.join(target_ws,fc+'_1'))
            arcpy.AddMessage (fc + " updated!")
        for dataset in AGOL_datasets:
            fc = dataset[0]
            if fc in ['DOCDatasetName1','DOCDatasetName2']: #Add your datasets here.
                # update recreation points
                target_ws = targetWorkspace
                DataUpdating(os.path.join(updateWorkspace,fc),os.path.join(target_ws,fc), os.path.join(target_ws,fc+'_1'))
            else:
                #update PAA GDB
                target_ws = targetWorkspace
                DataUpdating(os.path.join(updateWorkspace,fc),os.path.join(target_ws,fc), os.path.join(target_ws,fc+'_1'))
            arcpy.AddMessage (fc + " updated!")

    
    #Parameters for Script Tool to run with user input
    def RunWFSUpdating(): 

        cleanUp()
        AGOLMain()

        #Loop through each dataset listed in the WFS datasets list
        for dataset in WFS_Datasets:
            
            #set variables for iteration 
            wfsURL = "https://data.linz.govt.nz/services;key="+ str(APIKey) + "/wfs"
            wfsVersion = "2.0.0"
            wfsDataID = str(dataset[1])
            dataType = "layer"
            extentDataset = None
            lastUpdateFile = None
            changesetDatasetID = None
            targetDatasetID = None
            wfsDownloadType = "CSV"
            outputWorkspace = updateWorkspace
            datasetName = str(dataset[0])

            arcpy.AddMessage("Downloading...." + datasetName)

            WFSMain(wfsURL,wfsVersion,wfsDataID,dataType,extentDataset,lastUpdateFile,changesetDatasetID,targetDatasetID,wfsDownloadType,outputWorkspace,datasetName)
        arcpy.AddMessage ("All datasets downloaded to Update.gdb...")
        

        # truncate and append in PRD
        update_Data(WFS_Datasets,AGOL_datasets)
        arcpy.AddMessage('All datasets are updated in Data.gdb')
        arcpy.AddMessage('Ready to run update to YourVectorTilePackage.vtpk')
        
    #Primary function which executes nested functions CleanUp, AGOLMain, WFSMain, update_Data.    
    RunWFSUpdating()


    stop = timeit.default_timer()

    secondsElapsed = round(((stop - start)), 1)
    minutesElapsed = round((secondsElapsed/60), 1)
    hoursElapsed = round((minutesElapsed/60), 2)

    if secondsElapsed < 60:
        arcpy.AddMessage ("Time taken: " + str(secondsElapsed) + " seconds.")
    elif secondsElapsed > 60 and secondsElapsed <3600:
        arcpy.AddMessage ("Time taken: " + str(minutesElapsed) + " minutes.")
    elif minutesElapsed > 60:
        arcpy.AddMessage ("Time taken: " + str(hoursElapsed) + " hours.")

if __name__ == '__main__': 
    mainUpdateDatasets()

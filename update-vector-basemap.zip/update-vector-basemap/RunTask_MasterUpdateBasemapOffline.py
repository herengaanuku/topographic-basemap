############################################################
#Name: RunTask_MasterUpdateBasemapOffline.py
#Version: 1.0
#Creation Date: 17-05-2024
#Last updated: 17-05-2024
#Author - Julian Hitchman - Senior GIS Analyst, Herenga ā Nuku Aotearoa | Outdoor Acces Commission.

#Deployment Location: Local or Python Notebook
#Target Environemnt: ArcGIS Online or ArcGIS Enterprise.

#About: This is a master run script designed to run three other scripts in sequence as modules which will run a full update of a vector tile basemap project and any associated offline areas in your environment. 
# This scriptc can be run as a scheduled task from ArcGIS Pro. Altervatively it can be run as a standlone script from Python command line, Pyhthon notebook or IDE. 
#All listed scripts MUST be present in the same folder as this script for it to successfully run, as well as WFSDownload.py. 

########################################################

import os
import arcpy
import timeit

import Update_TopoDatasets
from Update_Datasets import mainUpdateDatasets
import Update_TopoVectorTileService
from Update_VectorTileService import mainVectorTileService
import Update_OfflineAreasPROD
from Update_OfflineAreas import mainUpdateOfflineAreas

#Start script timer
start= timeit.default_timer()
arcpy.AddMessage ("Starting timer... Beginning MASTER script...")

def mainFunction(): 
    arcpy.GetMessages()
    try: 
        arcpy.AddMessage ("PROCESS: Beginning to update basemap datasets......")
        mainUpdateDatasets()
        arcpy.AddMessage ("Topo basemap datasets have been updated.")

    except Exception as e:
        arcpy.AddMessage ("Somthing went wrong, check schedule task output below.")
        arcpy.AddMessage(e)

    try: 
        arcpy.AddMessage ("PROCESS: Beginning to package and update basemap tile service......")
        mainVectorTileService()
        arcpy.AddMessage ("Production Tile Service updated. Check AGOL and move old vtpk to archive/delete.")

    except Exception as e:
        arcpy.AddMessage ("Somthing went wrong, check schedule task output below.")
        arcpy.AddMessage(e)

    try: 
        arcpy.AddMessage ("PROCESS: Beginning to update offline areas for your apps offline areas......")
        mainUpdateOfflineAreas()
        arcpy.AddMessage ("Offline Areas updated for region webmaps.")
    except Exception as e:
        arcpy.AddMessage ("Somthing went wrong, check schedule task output below.")
        arcpy.AddMessage(e)


if __name__ == '__main__': 
    mainFunction()

stop = timeit.default_timer()

secondsElapsed = round(((stop - start)), 1)
minutesElapsed = round((secondsElapsed/60), 1)
hoursElapsed = round((minutesElapsed/60), 2)

if secondsElapsed < 60:
    arcpy.AddMessage ("TOTAL Time taken: " + str(secondsElapsed) + " seconds.")
elif secondsElapsed > 60 and secondsElapsed <3600:
    arcpy.AddMessage ("TOTAL Time taken: " + str(minutesElapsed) + " minutes.")
elif minutesElapsed > 60:
    arcpy.AddMessage ("TOTAL Time taken: " + str(hoursElapsed) + " hours.")
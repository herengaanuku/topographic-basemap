#Name: Update_VectorTileService.py
#Version: 1.1
#Editor - Julian Hitchman - Senior GIS Analyst, Herenga ā Nuku Aotearoa | Outdoor Acces Commission.
# Last Updated: 17/5/2024
#Deployment Location: Local or Python Notebook
#Target Environemnt: ArcGIS Online or ArcGIS Enterprise.

# OriginalName: replace_vector_tile_layer.py
# Author: Craig Williams
# Source: https://gist.github.com/williamscraigm/4ac9b129106dc43c129c435b50a58f25

# Description: Replaces a hosted vector tile layer with an updated version
# from a map in a project while retaining the item name, id, and url. 
#This script requires you to have already published an existing vector tile package to a vector tile service, in order to update it. 
# ####

import os
import datetime
import timeit
import arcpy
from arcgis.gis import GIS
from arcgis.mapping import VectorTileLayer
import keyring

def mainVectorTileService ():

    #Start script timer
    start= timeit.default_timer()
    arcpy.AddMessage ("Starting timer ... Beginning script...")

    now = datetime.datetime.now()
    date_time = "%d_%d_%d_%d_%d" % (now.year, now.month, now.day, now.hour, now.minute)
    monthYear = "%d_%d_%d" % (now.day,now.month, now.year)
    
    #Get credentials for login
    import keyring
    username = "YourUSername" #Add your username
    password = keyring.get_password("WindowsCredentialName", "YourUsername") #Add your Windows Credential name and username.

    gis = GIS("https://yourenviornment.arcgis.com", username, password) # Add your chosen update environment.

    # The id of the service to be replaced - current Vector Tile service
    published_service_id = '' #Add item ID here. 

    # The local folder, project file, and map containing the updated data.
    root_dir = r"ProjectDirectory"
    in_aprx = "ProjectName.aprx"
    map_name = "MapName"

    #Paths to existing tiling scheme XML file and index polygons featureclass
    tiling_scheme = r"YourTilingSchempath.xml"
    index_polygons = r"YourIndexPolygonFeatureClassPath"
    MaxScaleVaue = 00000.0000 #Add the max scale value of your tiling scheme (Integer)
    MinScaleValue =00000.0000 #Add min scale value of your tiling scheme (Integer)

    # Open the project with the updated map, prepare to package it as a vtpk
    project = arcpy.mp.ArcGISProject(os.path.join(root_dir, in_aprx))
    updated_map = project.listMaps(map_name)[0]
    updated_vtpk = os.path.join(root_dir, updated_map.name + "_" + monthYear + ".vtpk") 

    # Create a new vtpk from the map
    arcpy.AddMessage("Packaging map: " + updated_map.name)
    arcpy.CreateVectorTilePackage_management(updated_map, updated_vtpk, "EXISTING", tiling_scheme, "INDEXED", MinScaleValue, MaxScaleVaue, index_polygons)

    arcpy.AddMessage("Vector tile package successfully created: " + str(updated_vtpk))

    # Add the updated vtpk to the portal content and publish it as a hosted tile layer service.
    updated_service_title = map_name + "_" + monthYear
    vtpk_properties = {
        'title': updated_service_title,
        'description': 'Updated/staged version of ' + map_name,
        'tags': 'update, topographic, vector tile, '
    }
    vtpk_item = gis.content.add(item_properties=vtpk_properties, data=updated_vtpk)
    arcpy.AddMessage("Publishing updated tile layer...")
    vtpk_service_item = vtpk_item.publish()

    #Update replacement hosted tile service's properties to have offline enabled. 
    vector_layer_item = gis.content.get(vtpk_service_item.id)
    arcpy.AddMessage("Found tile layer")

    vector_tile_layer = VectorTileLayer.fromitem(vector_layer_item)
    vtl_manager = vector_tile_layer.manager
    vtl_manager.edit_tile_service(export_tiles_allowed = True)
    arcpy.AddMessage("Tile export enabled for: " + str(vector_tile_layer))

    #Replace the old hosted tile layer service with the updated one.
    target_service_item = gis.content.get(published_service_id)

    arcpy.AddMessage("Updated vector tile service: " + str(vtpk_service_item))
    arcpy.AddMessage("Target vector tile service: " + str(target_service_item))
    arcpy.AddMessage("Updating service...")
    gis.content.replace_service(published_service_id, vtpk_service_item.id)  


    arcpy.AddMessage("Target service successfully updated.")
    arcpy.AddMessage("Script Complete.")

    stop = timeit.default_timer()

    secondsElapsed = round(((stop - start)), 1)
    minutesElapsed = round((secondsElapsed/60), 1)
    hoursElapsed = round((minutesElapsed/60), 2)

    if secondsElapsed < 60:
        arcpy.AddMessage ("Time taken: " + str(secondsElapsed) + " seconds.")
    elif secondsElapsed > 60 and secondsElapsed <3600:
        arcpy.AddMessage ("Time taken: " + str(minutesElapsed) + " minutes.")
    elif minutesElapsed > 60:
        arcpy.AddMessage ("Time taken: " + str(hoursElapsed) + " hours.")


if __name__ == '__main__':
    mainVectorTileService()
